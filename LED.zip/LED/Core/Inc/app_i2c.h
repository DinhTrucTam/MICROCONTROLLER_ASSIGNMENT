/*
 * app_i2c.h
 *
 *  Created on: Dec 14, 2019
 *      Author: VAIO
 */

#ifndef APP_I2C_H_
#define APP_I2C_H_

void I2C_Init(void);

#endif /* APP_I2C_H_ */
